#pragma once

class Polar
{
public:
	Polar();
	Polar(float radius, float theta);

	float radius;
	float theta;
private:

};
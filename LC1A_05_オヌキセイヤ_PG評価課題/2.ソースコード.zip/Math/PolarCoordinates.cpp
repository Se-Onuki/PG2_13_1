#include "PolarCoordinates.hpp"



Polar::Polar() : radius(0), theta(0)
{
}

Polar::Polar(float radius, float theta) : radius(radius), theta(theta)
{
}
#pragma once

#include "./Object/Object.hpp"

class Entity :public Object
{
public:
	Entity();
	using Object::Object;

private:

};
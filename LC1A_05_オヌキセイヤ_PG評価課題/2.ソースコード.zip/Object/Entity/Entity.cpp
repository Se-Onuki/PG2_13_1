#include "Entity.hpp"
#include "PlayerManager.hpp"

Entity::Entity()
{
}
